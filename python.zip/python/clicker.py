import tkinter as tk
from tkinter import messagebox, filedialog, IntVar, StringVar, END
from ttkthemes import ThemedTk
from tkinter import ttk
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import psutil
import time
import threading
import os
import zipfile
import shutil
import re 
import math 

# --- WINDOWS-SPECIFIC REGISTRY IMPORT ---
try:
    import winreg
except ImportError:
    # This will be handled in the scan_persistence_locations method if not on Windows
    pass 


# --- 1. File Monitoring Handler Class (Unchanged) ---
class MonitorHandler(FileSystemEventHandler):
    def __init__(self, alert_var, log_callback, analysis_callback, exclude_list):
        super().__init__()
        self.alert_var = alert_var
        self.log_callback = log_callback
        self.analysis_callback = analysis_callback
        self.exclude_list = exclude_list 

    def _is_excluded(self, path):
        """Checks if the file path ends with a specified excluded extension."""
        if not path or not self.exclude_list:
            return False
        
        _, ext = os.path.splitext(path)
        ext = ext.lower().strip()
        
        return ext in self.exclude_list

    def on_modified(self, event):
        if not event.is_directory and not self._is_excluded(event.src_path):
            self.alert_user("modified", event.src_path)

    def on_created(self, event):
        if not event.is_directory and not self._is_excluded(event.src_path):
            self.alert_user("created", event.src_path)

    def on_deleted(self, event):
        if not event.is_directory and not self._is_excluded(event.src_path):
            self.alert_user("deleted", event.src_path, analyze=False)
            
    def on_moved(self, event):
        if not event.is_directory and not self._is_excluded(event.dest_path):
            self.alert_user("moved", f"{event.src_path} -> {event.dest_path}")

    def alert_user(self, event_type, path, analyze=True):
        message = f"File {event_type}: {path}"
        
        self.log_callback(message, tag="EVENT", is_event=True) 
        
        if analyze and event_type in ["created", "modified"]:
            analysis_path = path.split(" -> ")[-1] if " -> " in path else path
            self.analysis_callback(analysis_path)

        if self.alert_var.get():
            pass

# --- 2. Main Application Class ---
class App:
    def __init__(self, master):
        self.master = master
        master.title("🛡️ Secure File Monitor & System Health with Remediation")
        master.geometry("1150x750") # Adjusted size for the new buttons
        
        # --- Variables ---
        self.alert_var = IntVar(value=1)
        self.cpu_var = StringVar(value="CPU: --%")
        self.mem_var = StringVar(value="Memory: --%")
        self.path_var = StringVar(value="No folder selected.")
        self.status_var = StringVar(value="Status: Monitoring is OFF")
        
        # New Feature Variables
        self.risk_var = StringVar(value="Risk: 0%")
        self.event_count_var = StringVar(value="Events: 0")
        self.countdown_var = StringVar(value="Countdown: --")
        self.exclude_ext_var = StringVar(value=".tmp, .log, .db")
        self.exclude_list = {ext.strip() for ext in self.exclude_ext_var.get().lower().split(',')}

        self.event_counter = 0
        self.monitoring_timer = None
        self.countdown_seconds = 300 

        self.monitoring_thread = None
        self.observer = None
        
        # --- QUARANTINE SETUP ---
        self.QUARANTINE_FOLDER = os.path.join(os.path.expanduser('~'), 'FileMonitor_Quarantine')
        if not os.path.exists(self.QUARANTINE_FOLDER):
            os.makedirs(self.QUARANTINE_FOLDER)

        # --- UI Setup ---
        self.frame = ttk.Frame(master, padding="25 25 25 25")
        self.frame.pack(pady=10, padx=10, fill='both', expand=True)

        # Section 1: Folder Monitoring Control
        ttk.Label(self.frame, text="Real-Time Folder Monitoring Control", font=("", 11, "bold")).pack(pady=(0, 5))
        
        self.path_label = ttk.Label(self.frame, textvariable=self.path_var, wraplength=700, foreground='blue')
        self.path_label.pack(pady=5)
        
        self.status_label = ttk.Label(self.frame, textvariable=self.status_var, font=("", 10, "italic"))
        self.status_label.pack(pady=5)
        
        # Control Buttons
        button_frame = ttk.Frame(self.frame)
        button_frame.pack(pady=10)
        
        self.start_btn = ttk.Button(button_frame, text="Select & Start Monitoring", command=self.select_folder)
        self.start_btn.pack(side=tk.LEFT, padx=5, ipadx=10, ipady=5)

        self.stop_btn = ttk.Button(button_frame, text="Stop Monitoring", command=self.stop_monitoring, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5, ipadx=10, ipady=5)
        
        self.settings_btn = ttk.Button(button_frame, text="Settings", command=self.show_settings)
        self.settings_btn.pack(side=tk.LEFT, padx=5, ipadx=10, ipady=5)
        
        # Real-Time Results Frame
        ttk.Separator(self.frame, orient='horizontal').pack(fill='x', pady=10)
        
        ttk.Label(self.frame, text="Real-Time Monitoring Results", font=("", 10, "bold")).pack(pady=5)
        
        results_frame = ttk.Frame(self.frame)
        results_frame.pack(pady=5)
        
        self.event_count_label = ttk.Label(results_frame, textvariable=self.event_count_var, font=('', 10, 'bold'), foreground='#ff6961')
        self.event_count_label.pack(side=tk.LEFT, padx=15)
        
        self.risk_label = ttk.Label(results_frame, textvariable=self.risk_var, font=('', 10, 'bold'), foreground='orange')
        self.risk_label.pack(side=tk.LEFT, padx=15)
        
        self.countdown_label = ttk.Label(results_frame, textvariable=self.countdown_var, font=('', 10, 'bold'), foreground='#77dd77')
        self.countdown_label.pack(side=tk.LEFT, padx=15)
        
        ttk.Separator(self.frame, orient='horizontal').pack(fill='x', pady=10)
        
        # Section 2 & 3: Manual Scan and Log 
        ttk.Label(self.frame, text="Manual Scan | System Cleaning | Activity and Scan Log", font=("", 11, "bold")).pack(pady=(5, 5))
        
        # NEW BUTTON FRAME: (Bundles scan and clean buttons)
        scan_clean_frame = ttk.Frame(self.frame)
        scan_clean_frame.pack(pady=5)
        
        # NEW UPLOAD BUTTON:
        self.upload_clean_btn = ttk.Button(scan_clean_frame, text="Upload Crack File to Quarantine", command=self.upload_scan_clean_file, style='Accent.TButton')
        self.upload_clean_btn.pack(side=tk.LEFT, padx=10, ipadx=10, ipady=5)
        
        self.scan_btn = ttk.Button(scan_clean_frame, text="Analyze File/Folder", command=self.analyze_path, style='TButton')
        self.scan_btn.pack(side=tk.LEFT, padx=10, ipadx=10, ipady=5)
        
        self.clean_btn = ttk.Button(scan_clean_frame, text="Clean System (Temp/Cache)", command=self.clean_temporary_files)
        self.clean_btn.pack(side=tk.LEFT, padx=10, ipadx=10, ipady=5)
        
        self.crack_clean_btn = ttk.Button(scan_clean_frame, text="Clean Crack Software Remnants 🧹", command=self.clean_crack_software, style='TButton')
        self.crack_clean_btn.pack(side=tk.LEFT, padx=10, ipadx=10, ipady=5)
        
        self.log_text = tk.Text(self.frame, height=15, width=80, state=tk.DISABLED, wrap='word', bg='#2e2e2e', fg='#f0f0f0')
        self.log_text.pack(pady=10, fill='both', padx=10, expand=True)
        
        # Log Tag Configurations
        self.log_text.tag_config('EVENT', foreground='#ff6961') 
        self.log_text.tag_config('SCAN_HEADER', foreground='#77dd77', font=('', 10, 'bold'))
        self.log_text.tag_config('SCAN_DETAIL', foreground='#add8e6') 
        self.log_text.tag_config('RISK_HIGH', foreground='#ff3333', font=('', 10, 'bold'))
        self.log_text.tag_config('RISK_MED', foreground='#ffaa00')
        self.log_text.tag_config('INFO', foreground='#cccccc') 
        self.log_text.tag_config('CLEAN_FILE', foreground='#00cc00', font=('', 10, 'bold'))
        self.log_text.tag_config('RISK_FILE', foreground='#ff3333', font=('', 10, 'bold'))
        self.log_text.tag_config('QUARANTINED', foreground='#FFD700', font=('', 10, 'bold'))
        self.log_text.tag_config('TERMINATED', foreground='#00FFFF', font=('', 10, 'bold')) 

        # Section 4: System Monitoring Stats 
        ttk.Separator(self.frame, orient='horizontal').pack(fill='x', pady=15)
        
        ttk.Label(self.frame, text="System Health (Real-Time)", font=("", 10, "bold")).pack()
        
        stats_frame = ttk.Frame(self.frame)
        stats_frame.pack(pady=5)
        
        self.cpu_label = ttk.Label(stats_frame, textvariable=self.cpu_var)
        self.cpu_label.pack(side=tk.LEFT, padx=15)
        
        self.mem_label = ttk.Label(stats_frame, textvariable=self.mem_var)
        self.mem_label.pack(side=tk.LEFT, padx=15)
        
        ttk.Separator(self.frame, orient='horizontal').pack(fill='x', pady=15)

        self.exit_btn = ttk.Button(self.frame, text="Exit Application", command=self.on_closing)
        self.exit_btn.pack(pady=10, ipadx=10, ipady=5)
        
        master.protocol("WM_DELETE_WINDOW", self.on_closing)

        # Start monitoring threads
        self.sys_monitor_thread = threading.Thread(target=self.system_monitor, daemon=True)
        self.sys_monitor_thread.start()
        
        # Start Real-Time Process Security Scan
        self.security_scan_thread = threading.Thread(target=self.system_security_scan, daemon=True)
        self.security_scan_thread.start()

    # --- Logging Methods ---
    def update_log(self, message, tag='INFO', is_event=False):
        """Thread-safe method to schedule a log update on the main Tkinter thread."""
        self.master.after(0, self._perform_log_update, message, tag, is_event)

    def _perform_log_update(self, message, tag, is_event):
        """Performs the actual log text widget manipulation (must run in main thread)."""
        self.log_text.config(state=tk.NORMAL)
        
        timestamp = time.strftime("[%H:%M:%S]")
        self.log_text.insert(END, f"{timestamp} ", 'INFO')
        self.log_text.insert(END, message + "\n", tag)
        
        self.log_text.see(END)
        self.log_text.config(state=tk.DISABLED)
        
        if is_event and self.observer:
            self.event_counter += 1
            self.event_count_var.set(f"Events: {self.event_counter}")

    # --- Countdown Method ---
    def start_countdown(self):
        """Initializes and updates the monitoring countdown timer."""
        if self.monitoring_timer:
            self.master.after_cancel(self.monitoring_timer)
        
        if self.countdown_seconds <= 0:
            self.stop_monitoring(timed_out=True)
            self.countdown_seconds = 300
            return

        mins, secs = divmod(self.countdown_seconds, 60)
        self.countdown_var.set(f"Countdown: {mins:02d}:{secs:02d}")
        
        self.countdown_seconds -= 1
        self.monitoring_timer = self.master.after(1000, self.start_countdown)

    # --- File Cleaning/Remediation Method ---
    def quarantine_file(self, file_path):
        """Moves a high-risk file to the quarantine folder."""
        if not os.path.exists(file_path):
            self.update_log(f"Quarantine Error: File not found at {file_path}", tag="RISK_MED")
            return
            
        try:
            filename = os.path.basename(file_path)
            timestamp = time.strftime("_%Y%m%d_%H%M%S")
            new_filename = filename + timestamp
            
            dest_path = os.path.join(self.QUARANTINE_FOLDER, new_filename)
            
            shutil.move(file_path, dest_path)
            
            self.update_log(
                f"REMEDIATION SUCCESS: {filename} moved to Quarantine!", 
                tag="QUARANTINED"
            )
            self.update_log(f"Quarantine Location: {dest_path}", tag="INFO")
            
            if self.alert_var.get():
                messagebox.showwarning(
                    "High Risk File Quarantined",
                    f"A file ({filename}) with a high risk score was automatically moved to:\n{self.QUARANTINE_FOLDER}"
                )

        except Exception as e:
            self.update_log(
                f"QUARANTINE FAILED for {os.path.basename(file_path)}: {e}", 
                tag="RISK_HIGH"
            )

    # --- Process Cleaning/Remediation Method ---
    def terminate_process(self, process, reason):
        """Terminates a high-risk process."""
        try:
            name = process.name()
            pid = process.pid
            
            if pid == os.getpid():
                # Prevent the application from terminating itself
                return

            process.terminate()
            
            self.update_log(
                f"PROCESS CLEANED: PID {pid}, Name: {name} (Reason: {reason})",
                tag="TERMINATED"
            )
            
            if self.alert_var.get():
                messagebox.showerror(
                    "High Risk Process Terminated",
                    f"A malicious/high-risk process was terminated:\nPID: {pid}\nName: {name}\nReason: {reason}"
                )

        except psutil.NoSuchProcess:
            self.update_log(f"Process {pid} already terminated.", tag="INFO")
        except Exception as e:
            self.update_log(f"PROCESS TERMINATION FAILED for {name}: {e}", tag="RISK_HIGH")

    # --- System Cleaning Method ---
    def clean_temporary_files(self):
        """Attempts to delete temporary files and clear cache directories."""
        self.update_log("--- Starting System Cleanup: Temporary Files & Cache ---", tag="SCAN_HEADER")
        
        # Directories to target (common temp, cache, and trash locations)
        target_dirs = [
            os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Temp'),  # Windows Temp
            os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Microsoft', 'Windows', 'Temporary Internet Files'), # IE Cache 
            os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Google', 'Chrome', 'User Data', 'Default', 'Cache'), # Chrome Cache
            os.environ.get('TEMP', ''), # System Temp fallback
        ]
        
        # Filter out non-existent or empty paths
        dirs_to_clean = [d for d in target_dirs if d and os.path.exists(d)]
        
        total_items_cleaned = 0
        total_size_freed = 0
        
        for directory in dirs_to_clean:
            self.update_log(f" > Cleaning directory: {os.path.basename(directory)}", tag="SCAN_DETAIL")
            
            # Simple cleanup loop
            for item in os.listdir(directory):
                path = os.path.join(directory, item)
                
                # Exclude important files or recent logs/dumps (keep recent 7 days)
                if item.lower().endswith(('.ini', '.log', '.dat', '.dmp')) and os.path.getmtime(path) > time.time() - (60 * 60 * 24 * 7): 
                    continue

                try:
                    if os.path.isfile(path):
                        size = os.path.getsize(path)
                        os.remove(path)
                        total_items_cleaned += 1
                        total_size_freed += size
                    elif os.path.isdir(path):
                        # Use shutil.rmtree for directories, ignore errors for files in use
                        shutil.rmtree(path, ignore_errors=True)
                        total_items_cleaned += 1
                except Exception as e:
                    # Log failure without stopping the entire cleanup
                    self.update_log(f"   - Failed to clean {item}: {e}", tag="RISK_MED")
        
        # Log the final result
        if total_items_cleaned > 0:
            freed_mb = total_size_freed / (1024 * 1024)
            self.update_log(
                f"CLEANUP COMPLETE: Removed {total_items_cleaned} items. Freed {freed_mb:.2f} MB.",
                tag="CLEAN_FILE"
            )
        else:
            self.update_log("CLEANUP COMPLETE: No old or unnecessary temporary files found.", tag="INFO")

    # --- Combined Crack Software Cleanup Method ---
    def clean_crack_software(self):
        """Runs an aggressive cleanup targeting temporary files and persistence locations."""
        
        # Run in a separate thread to prevent the UI from freezing during the scan
        threading.Thread(target=self._run_crack_cleaner_in_thread, daemon=True).start()

    def _run_crack_cleaner_in_thread(self):
        self.update_log("\n--- 🔨 STARTING AGGRESSIVE CRACK SOFTWARE CLEANUP ---", tag="RISK_HIGH")
        
        # 1. Run the Persistence Scan
        self.update_log("-> Step 1/2: Checking Persistence Locations (Registry/Startup)...", tag="SCAN_HEADER")
        self.scan_persistence_locations()
        
        # 2. Run the Temporary/Cache File Cleanup
        self.update_log("-> Step 2/2: Cleaning Temporary Files and Cache Directories...", tag="SCAN_HEADER")
        self.clean_temporary_files()
        
        self.update_log("--- 🥳 CRACK CLEANUP ROUTINE COMPLETE. ---", tag="CLEAN_FILE")
        self.update_log("NOTE: Review log for 'HIGH RISK' persistence entries requiring manual deletion.", tag="INFO")

    # --- New Feature: Upload, Scan, and Clean ---
    def upload_scan_clean_file(self):
        """Prompts user to select a single file, analyzes it, and quarantines it if high risk."""
        # Ask the user to select a single file
        file_path = filedialog.askopenfilename(
            title="Select Crack Software File to Analyze and Clean",
            filetypes=[("All Files", "*.*")]
        )
        
        if not file_path:
            self.update_log("File selection cancelled by user.", tag="INFO")
            return

        # Run the intensive analysis and cleaning in a separate thread
        threading.Thread(target=self._run_upload_scan_clean_thread, args=(file_path,), daemon=True).start()

    def _run_upload_scan_clean_thread(self, file_path):
        """Threaded function to perform single-file analysis and cleaning."""
        try:
            # FIX APPLIED HERE: Ensuring the f-string is properly closed.
            self.update_log(f"\n--- 📤 STARTING UPLOAD & CLEAN ANALYSIS for: {os.path.basename(file_path)} ---", tag="RISK_HIGH")
            
            # Use the existing analysis logic (handles zip/single files)
            if file_path.lower().endswith(('.zip', '.rar', '.7z')):
                risk_score = self._analyze_zip_file(file_path)
            else:
                risk_score = self._analyze_single_file(file_path)
            
            self._update_risk_display(risk_score)
            
            # Automatic Remediation (Quarantine)
            if risk_score >= 75:
                self.update_log(f"CRITICAL RISK DETECTED ({risk_score}%). INITIATING QUARANTINE.", tag="RISK_HIGH")
                self.quarantine_file(file_path)
                final_status = "REMEDIATED (QUARANTINED)"
                tag = "QUARANTINED"
            else:
                final_status = "CLEAN (Low Risk)"
                tag = "CLEAN_FILE"
                
            self.update_log(f"--- UPLOAD & CLEAN RESULT: {final_status} (Risk: {risk_score}%) ---", tag=tag)

        except Exception as e:
            self.update_log(f"UPLOAD & CLEAN FAILED for {os.path.basename(file_path)}: {e}", tag="RISK_HIGH")


    # --- Persistence Scanning Method (Windows-specific) ---
    def scan_persistence_locations(self):
        """Checks common Windows Registry Run keys and startup folders for suspicious entries."""
        
        # Check if the required winreg module is available (Windows check)
        try:
            import winreg
        except ImportError:
            self.update_log("Persistence scan skipped: winreg module not available (Windows only).", tag="INFO")
            return 0 

        suspicious_count = 0
        self.update_log("--- Starting Persistence Location Scan (Startup/Registry) ---", tag="SCAN_HEADER")

        # 1. Registry Keys to Check (Common Autorun locations)
        registry_paths = [
            (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
        ]

        for hkey, subkey in registry_paths:
            try:
                key = winreg.OpenKey(hkey, subkey, 0, winreg.KEY_READ)
                i = 0
                while True:
                    try:
                        name, value, type = winreg.EnumValue(key, i)
                        value_str = str(value).lower()
                        
                        # Heuristics: Look for suspicious extensions or names in the command
                        if value_str.endswith(('.exe', '.dll', '.vbs', '.js', '.bat')) or \
                           any(k in value_str for k in ['keygen', 'crack', 'patch', 'bot', 'miner']):
                            
                            self.update_log(
                                f"  > RISK: Found suspicious startup entry: Name='{name}', Value='{value_str}'",
                                tag="RISK_HIGH"
                            )
                            suspicious_count += 1
                        
                        i += 1
                    except OSError:
                        break # End of key entries
                winreg.CloseKey(key)
            except FileNotFoundError:
                pass # Key does not exist
            except Exception as e:
                self.update_log(f"  > Error reading registry key {subkey}: {e}", tag="RISK_MED")

        # 2. Startup Folder Check (Current User)
        startup_folder = os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
        if os.path.exists(startup_folder):
            for item in os.listdir(startup_folder):
                if item.lower().endswith(('.lnk', '.exe', '.bat', '.vbs')):
                    self.update_log(
                        f"  > RISK: Found suspicious item in Startup folder: {item}",
                        tag="RISK_HIGH"
                    )
                    suspicious_count += 1
        
        if suspicious_count == 0:
            self.update_log("Persistence scan found no highly suspicious startup entries.", tag="INFO")
        else:
             self.update_log("Persistence scan completed. Review HIGH RISK entries for manual removal.", tag="RISK_HIGH")
            
        return suspicious_count


    # --- Real-Time File Analysis and Risk Calculation ---
    def realtime_analysis(self, path):
        if not os.path.exists(path) or os.path.isdir(path):
            return

        threading.Thread(target=self._run_realtime_analysis_in_thread, args=(path,), daemon=True).start()

    def _run_realtime_analysis_in_thread(self, path):
        risk_score = 0
        try:
            if not os.path.exists(path):
                return
                
            self.update_log(f"--- Real-Time Scan: {os.path.basename(path)} ---", tag="SCAN_HEADER")

            if path.lower().endswith('.zip'):
                risk_score = self._analyze_zip_file(path)
            else:
                risk_score = self._analyze_single_file(path)
                
            self._update_risk_display(risk_score)
            
            # CLEANING LOGIC (FILE QUARANTINE):
            if risk_score >= 75:
                self.update_log(f"CRITICAL RISK DETECTED ({risk_score}%). INITIATING QUARANTINE.", tag="RISK_HIGH")
                self.quarantine_file(path)
                verdict = "REMEDIATED"
                verdict_tag = "QUARANTINED"
            else:
                verdict = "RISK" if risk_score >= 40 else "CLEAN"
                verdict_tag = "RISK_FILE" if verdict == "RISK" else "CLEAN_FILE"
                
            self.update_log(f"--- Scan Result: {verdict} (Risk: {risk_score}%) ---", tag=verdict_tag)
                
        except Exception as e:
            self.update_log(f"Real-Time Analysis Error for {os.path.basename(path)}: {e}", tag="RISK_HIGH")

    # --- Risk Display ---
    def _update_risk_display(self, score):
        self.master.after(0, self.__set_risk_var, score)

    def __set_risk_var(self, score):
        tag = 'RISK_HIGH' if score >= 75 else ('RISK_MED' if score >= 40 else 'INFO')
        self.risk_label.config(foreground=self.log_text.tag_cget(tag, "foreground"))
        self.risk_var.set(f"Risk: {score}%")
        
    # --- Helper for Encryption Detection (Entropy) ---
    def _calculate_entropy(self, data):
        """Calculates Shannon entropy of the given data."""
        if not data:
            return 0.0
        
        counts = [0] * 256
        for byte in data:
            counts[byte] += 1
            
        entropy = 0.0
        data_len = len(data)
        
        for count in counts:
            if count > 0:
                probability = count / data_len
                # Formula: -p * log2(p)
                entropy -= probability * math.log2(probability)
        
        return entropy / 8 # Normalize to 0-1 range (maximum entropy of 8 bits)


    # --- File Analysis Helpers (Includes Entropy Check) ---
    def _analyze_single_file(self, file_path):
        risk = 0
        try:
            size_bytes = os.path.getsize(file_path)
            size_kb = size_bytes / 1024
            
            self.update_log(f" > Size: {size_bytes} bytes ({size_kb:.2f} KB)", tag="SCAN_DETAIL")
            
            filename = os.path.basename(file_path).lower()
            ext = os.path.splitext(filename)[1].lower()
            
            # Check 1: File Extension Risk
            if ext in ['.exe', '.bat', '.cmd', '.sh', '.vbs']:
                risk = 90
                self.update_log(" > SECURITY ALERT: Executable/Script found. HIGH RISK!", tag="RISK_HIGH")
            elif ext in ['.dll', '.ps1', '.js', '.lnk']:
                risk = 80 
                self.update_log(" > SECURITY WARNING: Potential dangerous file type. INITIATING QUARANTINE.", tag="RISK_HIGH")
            else:
                risk = 5

            # Check 2: Crack Software Name Heuristic
            crack_keywords = r'crack|keygen|patch|activator|serial|loader|setup'
            if re.search(crack_keywords, filename) and ext in ['.exe', '.zip', '.rar']:
                risk = max(risk, 95)
                self.update_log(" > CRACK SOFTWARE DETECTED: Suspicious name heuristic triggered!", tag="RISK_HIGH")
                
            # Check 3: Encrypted File (High Entropy) Heuristic
            with open(file_path, 'rb') as f:
                sample_data = f.read(4096)
            
            if sample_data:
                entropy_score = self._calculate_entropy(sample_data)
                
                # Entropy > 0.95 is extremely high (encrypted/compressed data)
                if entropy_score > 0.95 and ext not in ['.zip', '.rar', '.jpg', '.mp4', '.gz', '.7z']:
                    risk = max(risk, 85) 
                    self.update_log(f" > CRITICAL ENCRYPTION ALERT: High entropy detected ({entropy_score:.2f}).", tag="RISK_HIGH")
                elif entropy_score > 0.90:
                    risk = max(risk, 40)
                    self.update_log(f" > WARNING: High entropy detected ({entropy_score:.2f}).", tag="RISK_MED")
                else:
                    self.update_log(f" > Entropy: {entropy_score:.2f} (Normal)", tag="SCAN_DETAIL")


            if risk < 40 and not re.search(crack_keywords, filename):
                self.update_log(" > File Check: Common data/media type. Low Risk.", tag="INFO")
            
            return risk

        except FileNotFoundError:
             self.update_log(" > File Analysis Error: File not found.", tag="RISK_HIGH")
             return 10 
        except Exception as e:
            self.update_log(f" > File Read Error: {e}", tag="RISK_HIGH")
            return 10
        
    def _analyze_zip_file(self, zip_path):
        risk = 0
        self.update_log(" > File Type: ZIP Archive", tag="SCAN_DETAIL")
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                file_list = zf.namelist()
                num_files = len(file_list)
                
                self.update_log(f" > Total entries: {num_files}", tag="SCAN_DETAIL")
                
                suspicious_count = 0
                for name in file_list:
                    # Check for suspicious executables inside
                    if os.path.basename(name).lower().endswith(('.exe', '.bat', '.cmd', '.vbs', '.dll', '.ps1')):
                        self.update_log(f" > WARNING: Suspicious executable/script inside: {name}", tag="RISK_MED")
                        suspicious_count += 1
                    # Check for crack keywords inside
                    crack_keywords = r'crack|keygen|patch|activator|serial'
                    if re.search(crack_keywords, os.path.basename(name).lower()):
                         self.update_log(f" > WARNING: Crack keyword found inside: {name}", tag="RISK_MED")
                         suspicious_count += 1

                if suspicious_count > 0:
                    risk = 30 + min(suspicious_count * 10, 70) 
                    self.update_log(f" > MAJOR WARNING: Found {suspicious_count} suspicious entries in the archive!", tag="RISK_HIGH")
                else:
                    risk = 20
                    self.update_log(" > Archive Check: No highly suspicious files found.", tag="SCAN_DETAIL")
            
            return risk

        except zipfile.BadZipFile:
            self.update_log(" > Error: The file is not a valid ZIP archive.", tag="RISK_HIGH")
            return 80
        except Exception as e:
            self.update_log(f" > Error reading ZIP file: {e}", tag="RISK_HIGH")
            return 80
            
    # --- Process Analysis Helper (Includes Persistence Heuristic) ---
    def _analyze_process(self, process):
        risk = 0
        reason = ""
        
        try:
            p_name = process.name().lower()
            p_exe = process.exe()
            p_cmdline = ' '.join(process.cmdline())
            
            # Rule 1: "Botto" / Generic Suspicious Names (High Risk)
            bot_keywords = r'bot|miner|worm|trojan|adware|updater|launcher|patcher|keygen|crack'
            if re.search(bot_keywords, p_name) or re.search(bot_keywords, p_exe.lower()):
                risk = max(risk, 95)
                reason = "Malicious name/keyword detected."
            
            # Rule 2: Running from highly suspicious locations (e.g., Temp folders)
            temp_dirs = [os.environ.get('TEMP', ''), os.environ.get('TMP', ''), '/tmp', '/var/tmp']
            if any(td and p_exe.startswith(td) for td in temp_dirs if td):
                risk = max(risk, 85)
                if not reason: reason = "Running from highly suspicious temp directory."

            # Rule 3: Crack Software Heuristic (Medium-High Risk)
            crack_name_keywords = r'keygen|crack|patch|activator|serial'
            if re.search(crack_name_keywords, p_name):
                risk = max(risk, 75)
                if not reason: reason = "Crack software utility name detected."

            # Rule 4: Suspicious Persistence Attempt Heuristic
            # Checks for keywords related to registry persistence in command line for already risky processes.
            if risk >= 75 and ('HKCU' in p_cmdline or 'Run' in p_cmdline or 'schtasks' in p_cmdline):
                 risk = max(risk, 98)
                 reason = "Suspicious process attempting persistence (Registry/Scheduled Task)."


        except psutil.NoSuchProcess:
            return 0, ""
        except Exception:
            return 0, "" 

        return risk, reason

    # --- Real-Time Process Scanner (MODIFIED) ---
    def system_security_scan(self):
        """Continuously scans running processes and persistence locations."""
        time.sleep(10)
        
        scan_counter = 0

        while True:
            # --- Process Scan ---
            high_risk_found = False
            
            for proc in psutil.process_iter(['name', 'exe', 'cmdline']):
                try:
                    risk_score, reason = self._analyze_process(proc)
                    
                    if risk_score >= 75:
                        high_risk_found = True
                        self.update_log(
                            f"PROCESS ALERT: PID {proc.pid}, Risk: {risk_score}%, Reason: {reason}",
                            tag="RISK_HIGH"
                        )
                        # CLEANING ACTION: Terminate the high-risk process
                        self.terminate_process(proc, reason)
                        
                except Exception:
                    continue

            if high_risk_found:
                 self.update_log("--- Process Cleaning Cycle Complete ---", tag="TERMINATED")

            # --- Persistence Scan (Runs less frequently) ---
            scan_counter += 1
            if scan_counter >= 3: # Run the persistence scan every 3 process cycles (approx 30 seconds)
                self.scan_persistence_locations()
                scan_counter = 0

            time.sleep(10)


    # --- Manual Scanning/Analysis Methods ---
    def analyze_path(self):
        path = filedialog.askopenfilename()
        if not path:
            path = filedialog.askdirectory()
            
        if not path:
            return

        threading.Thread(target=self._run_manual_analysis_in_thread, args=(path,), daemon=True).start()

    def _run_manual_analysis_in_thread(self, path):
        risk_score = 0
        try:
            self.update_log(f"--- Manual Scan Starting for: {path} ---", tag="SCAN_HEADER")
            
            if os.path.isfile(path):
                if path.lower().endswith('.zip'):
                    risk_score = self._analyze_zip_file(path)
                else:
                    risk_score = self._analyze_single_file(path)
            elif os.path.isdir(path):
                self._analyze_folder(path)
                risk_score = 0 
            else:
                self.update_log(f"Error: Path not found or is special file type.", tag="RISK_HIGH")
                risk_score = 100
            
            self._update_risk_display(risk_score)

            if os.path.isfile(path):
                if risk_score >= 75:
                    self.update_log("CRITICAL RISK DETECTED. File should be QUARANTINED manually.", tag="RISK_HIGH")
                    verdict = "RISK (QUARANTINE RECOMMENDED)"
                    verdict_tag = "RISK_FILE"
                else:
                    verdict = "RISK" if risk_score >= 40 else "CLEAN"
                    verdict_tag = "RISK_FILE" if verdict == "RISK" else "CLEAN_FILE"
                    
                self.update_log(f"--- Scan Result: {verdict} (Risk: {risk_score}%) ---", tag=verdict_tag)
            
        except Exception as e:
            self.update_log(f"An unexpected error occurred during manual analysis: {e}", tag="RISK_HIGH")
            
        if os.path.isdir(path):
             self.update_log(f"--- Manual Scan Complete (Folder Analysis) ---", tag="SCAN_HEADER")

    def _analyze_folder(self, folder_path):
        self.update_log("Path Type: Folder/Directory", tag="SCAN_DETAIL")
        
        file_count = 0
        total_size = 0
        
        for entry in os.scandir(folder_path):
            try:
                if entry.is_file():
                    file_count += 1
                    total_size += entry.stat().st_size
                elif entry.is_dir():
                    self.update_log(f" - Subdirectory found: {entry.name}", tag="SCAN_DETAIL")
            except Exception as e:
                self.update_log(f" - Error accessing entry {entry.name}: {e}", tag="RISK_HIGH")
                
        self.update_log(f"Total files in top level: {file_count}", tag="SCAN_DETAIL")
        self.update_log(f"Total size (top level files): {total_size / (1024*1024):.2f} MB", tag="SCAN_DETAIL")

    # --- Monitoring and System Methods ---
    def select_folder(self):
        """Opens a dialog to select a folder and starts monitoring if a path is chosen."""
        folder_path = filedialog.askdirectory()
        if folder_path:
            self.start_monitoring(folder_path)

    def start_monitoring(self, folder_path):
        if self.observer is not None:
            self.stop_monitoring(notify=False)
            
        self.exclude_list = {ext.strip() for ext in self.exclude_ext_var.get().lower().split(',') if ext.strip()}

        self.observer = Observer()
        handler = MonitorHandler(
            self.alert_var, 
            self.update_log,
            self.realtime_analysis,
            self.exclude_list 
        ) 
        
        self.observer.schedule(handler, folder_path, recursive=True)
        self.observer.start()

        self.event_counter = 0
        self.event_count_var.set("Events: 0")
        self.risk_var.set("Risk: 0%")
        self.countdown_seconds = 300 
        self.start_countdown() 
        
        self.path_var.set(f"Monitoring: {folder_path}")
        self.status_var.set("Status: Monitoring is ON (Recursive & Timed)")
        self.stop_btn.config(state=tk.NORMAL)
        self.start_btn.config(text="Change Folder", state=tk.NORMAL)

        self.update_log(f"--- Real-Time Monitoring STARTED for {folder_path} ---", tag="INFO")
        self.update_log(f"--- EXCLUDING: {', '.join(self.exclude_list) if self.exclude_list else 'None'} ---", tag="INFO")

    def stop_monitoring(self, notify=True, timed_out=False):
        if self.observer:
            self.observer.stop()
            self.observer.join()

        self.observer = None
        
        if self.monitoring_timer:
            self.master.after_cancel(self.monitoring_timer)
            self.monitoring_timer = None

        message = "Monitoring has been stopped."
        if timed_out:
            message = "Monitoring stopped automatically due to countdown expiry."
            self.update_log("--- Monitoring TIMED OUT and STOPPED ---", tag="RISK_MED")
        elif notify:
            self.update_log("--- Real-Time Monitoring STOPPED ---", tag="INFO")

        if notify:
            messagebox.showinfo("Monitoring Stopped", message)

        self.path_var.set("No folder selected.")
        self.status_var.set("Status: Monitoring is OFF")
        self.stop_btn.config(state=tk.DISABLED)
        self.start_btn.config(text="Select & Start Monitoring", state=tk.NORMAL)
        self.countdown_var.set("Countdown: --")
        self.risk_label.config(foreground='#cccccc')
        
    def system_monitor(self):
        while True:
            try:
                cpu_percent = psutil.cpu_percent(interval=1)
                mem_info = psutil.virtual_memory()
                mem_percent = mem_info.percent
                
                self.cpu_var.set(f"CPU: {cpu_percent}%")
                self.mem_var.set(f"Memory: {mem_percent}%")
                
                time.sleep(3)
            except Exception:
                time.sleep(10)

    def show_settings(self):
        settings_window = tk.Toplevel(self.master)
        settings_window.title("Settings")
        settings_window.geometry("450x200")
        settings_window.resizable(False, False)
        settings_window.grab_set()

        setting_frame = ttk.Frame(settings_window, padding="15")
        setting_frame.pack(fill='both', expand=True)

        alert_check = ttk.Checkbutton(
            setting_frame, 
            text="Enable Pop-up File Alerts", 
            variable=self.alert_var
        )
        alert_check.grid(row=0, column=0, columnspan=2, pady=10, sticky='w')
        
        ttk.Label(setting_frame, text="Exclude Extensions (e.g., .tmp, .log):").grid(row=1, column=0, pady=5, sticky='w')
        
        ext_entry = ttk.Entry(setting_frame, textvariable=self.exclude_ext_var, width=30)
        ext_entry.grid(row=1, column=1, pady=5, padx=5, sticky='ew')
        
        close_btn = ttk.Button(settings_window, text="Close & Apply", command=settings_window.destroy)
        close_btn.pack(pady=10)
        
    def on_closing(self):
        if self.observer:
            self.observer.stop()
        
        if self.observer and self.observer.is_alive():
             self.observer.join()
        
        if self.monitoring_timer:
            self.master.after_cancel(self.monitoring_timer)
            
        self.master.destroy()


# --- 3. Run the Application ---
if __name__ == "__main__":
    root = ThemedTk(theme="arc") 
    app = App(root)
    root.mainloop()